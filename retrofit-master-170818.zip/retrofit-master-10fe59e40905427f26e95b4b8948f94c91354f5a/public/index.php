<?php

$app = require_once __DIR__ . '/../backend/app/app.php';
$app->run();
