export { default as Device } from './Device';
