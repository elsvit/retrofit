import * as ContactInfo from './ContactInfo/index';
import { default as SpecificationButton } from './SpecificationButton';

export { ContactInfo, SpecificationButton };
