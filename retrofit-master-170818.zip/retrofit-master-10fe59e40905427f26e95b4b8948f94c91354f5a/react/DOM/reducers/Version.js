/* global APP_STATE_VERSION_PROVIDED_BY_WEBPACK */
const defaultState = APP_STATE_VERSION_PROVIDED_BY_WEBPACK;

export default (state = defaultState, event = {}) => (state);
