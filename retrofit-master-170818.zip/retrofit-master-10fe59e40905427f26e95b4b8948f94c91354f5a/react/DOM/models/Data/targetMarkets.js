const data = {
  "Europe":
  {
    "English": {"target": "default", "uiLocale": "en_US"},
    "Deutsch": {"target": "de-ch", "uiLocale": "de_CH"}
  }
};

export default data;
