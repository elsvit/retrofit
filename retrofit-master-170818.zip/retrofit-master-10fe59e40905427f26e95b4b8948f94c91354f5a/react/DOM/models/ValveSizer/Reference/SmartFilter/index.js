export SmartPropertiesManager from './SmartPropertiesManager';
