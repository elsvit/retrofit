import React, { Component, View } from 'react-native';

class Application extends Component {
    render() {
        return (
          <View/>
        );
    }
}

export default Application;