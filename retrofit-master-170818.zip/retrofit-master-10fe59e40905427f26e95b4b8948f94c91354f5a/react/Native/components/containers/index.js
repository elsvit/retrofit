import React, { Component, PropTypes } from 'react-native';

import Application from './Application';

class IndexContainer extends Component {
    static get propTypes() {

    }

    render() {
        return (
            <Application />
        )
    }
}

export default IndexContainer;
