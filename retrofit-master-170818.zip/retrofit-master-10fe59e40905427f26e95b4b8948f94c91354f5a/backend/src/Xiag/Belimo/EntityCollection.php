<?php

namespace Xiag\Belimo;


class EntityCollection
{
    const RETROFIT_WATER_PRODUCT = 'retrofit_water_product';
    const VALVESIZER_COMBO = 'valvesizer_combo';
    const RETROFIT_WATER_ACCESSORY = 'retrofit_water_accessory';
    const VALVESIZER_SERIE = 'valvesizer_serie';
    const VALVESIZER_ACTUATOR = 'valvesizer_actuator';
    const VALVESIZER_VALVE = 'valvesizer_valve';
    const RETROFIT_AIR_PRODUCT = 'retrofit_air_product';
    const RETROFIT_AIR_ACCESSORY = 'retrofit_air_accessory';
    const RETROFIT_AIR_ORIGINAL = 'retrofit_air_original';
    const RETROFIT_WATER_ORIGINAL = 'retrofit_water_original';
}
