<?php


namespace Xiag\Belimo\Import;


class InvalidParameterException extends ImportException
{

}