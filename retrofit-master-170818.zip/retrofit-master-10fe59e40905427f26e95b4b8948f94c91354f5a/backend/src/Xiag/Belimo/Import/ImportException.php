<?php

namespace Xiag\Belimo\Import;


use Xiag\Belimo\Exception;

class ImportException extends Exception
{

}