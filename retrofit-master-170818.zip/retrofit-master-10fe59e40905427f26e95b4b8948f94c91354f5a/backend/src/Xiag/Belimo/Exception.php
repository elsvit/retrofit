<?php

namespace Xiag\Belimo;


class Exception extends \Exception
{

}
