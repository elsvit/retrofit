<?php

namespace Xiag\Belimo;


interface Namespaced
{
    /**
     * @param string $namespace
     * @return void
     */
    function setNamespace($namespace);
}
